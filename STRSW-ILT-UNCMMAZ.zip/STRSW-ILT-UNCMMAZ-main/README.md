# STRSW-ILT-UNCMMAZ
Ths repository contains all the files needed for the course Integrating Hybrid Clouds with Microsoft Azure
